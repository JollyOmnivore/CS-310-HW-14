package com.example.hw14

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.core.graphics.toColor
import androidx.recyclerview.widget.RecyclerView

class AcronymAdapter (val acronyms: MutableList<Acronym>) : RecyclerView.Adapter<AcronymAdapter.AcroymViewHolder>(){
    class AcroymViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        val textViewAcronym : TextView = itemView.findViewById<TextView>(R.id.textViewAcronym)
        val buttonUpper : Button = itemView.findViewById<Button>(R.id.buttonUpper)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AcroymViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.acroynm_layout,parent,false)
        return AcroymViewHolder(view)
    }

    override fun getItemCount(): Int {
        return acronyms.size
    }

    override fun onBindViewHolder(holder: AcroymViewHolder, position: Int) {
        val currentAcronym = acronyms[position]

        holder.textViewAcronym.text = currentAcronym.acronym
        holder.buttonUpper.setOnClickListener {
            acronyms.removeAt(position)
            notifyItemRemoved(position)
        }
    }

}
