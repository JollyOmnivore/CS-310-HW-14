package com.example.hw14

data class Acronym(val acronym: String, val priority: String){}
