package com.example.hw14

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val data = mutableListOf<Acronym>()

        fun updateData(data: MutableList<Acronym>) {

            var recyclerView: RecyclerView = findViewById<RecyclerView>(R.id.recyclerViewAcronyms)
            var acronymAdapter: AcronymAdapter = AcronymAdapter(data)
            recyclerView.adapter= acronymAdapter
        }



        val buttonAdd1: Button = findViewById<Button>(R.id.buttonAdd1)
        val radioGroup: RadioGroup = findViewById<RadioGroup>(R.id.radioGroupPriority)
        buttonAdd1.setOnClickListener{
            val question = findViewById<EditText>(R.id.inputText).text.toString()
            val priority: String = when (radioGroup.checkedRadioButtonId) {
                R.id.Low -> "Low"
                R.id.radioButton2 -> "Medium"
                R.id.radioButton3 -> "High"
                else -> "Low"
            }
            data.add(Acronym(question,priority))
            updateData(data)



        }





    }
}